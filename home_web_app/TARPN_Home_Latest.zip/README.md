# TARPN_Home
User Interface for the TARPN Packet Network. Runs on Raspberry Pi.<br>
This app uses a Tornado web server on the Raspberry Pi.<br> 
It uses websockets to talk to the web pages and uses the serial port interface to talk to the node ports.
